import { SpamDetectionResult } from '../types';
import { SPAM_INDICATORS } from '../utils/constants';

/**
 * A simple mock service to simulate spam detection
 * In a real application, this would call a backend API that uses the trained model
 */
export const detectSpam = (emailContent: string): Promise<SpamDetectionResult> => {
  return new Promise((resolve) => {
    // Simulate API call delay
    setTimeout(() => {
      const normalizedContent = emailContent.toLowerCase();
      
      // Count spam indicators in the email content
      let spamScore = 0;
      let totalIndicators = 0;
      
      SPAM_INDICATORS.forEach(indicator => {
        const regex = new RegExp(`\\b${indicator}\\b`, 'gi');
        const matches = (normalizedContent.match(regex) || []).length;
        if (matches > 0) {
          spamScore += matches;
          totalIndicators += 1;
        }
      });
      
      // Calculate confidence based on the number of spam indicators found
      // Adjust thresholds as needed
      const isSpam = spamScore >= 2;
      
      // Calculate a confidence score between 0 and 1
      // More sophisticated in a real model
      const confidence = Math.min(0.5 + (spamScore / 10), 0.99);
      
      resolve({
        isSpam,
        confidence: confidence,
        prediction: isSpam ? 'SPAM' : 'HAM'
      });
    }, 800); // Simulate processing time
  });
};