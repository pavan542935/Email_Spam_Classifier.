import React, { useState } from 'react';
import Header from './components/Header';
import EmailInput from './components/EmailInput';
import ResultDisplay from './components/ResultDisplay';
import Footer from './components/Footer';
import { useSpamDetection } from './hooks/useSpamDetection';
import { Moon, Sun } from 'lucide-react';

function App() {
  const { 
    email, 
    setEmail, 
    result, 
    isLoading, 
    error, 
    checkSpam, 
    resetForm 
  } = useSpamDetection();
  
  const [darkMode, setDarkMode] = useState(false);
  
  const toggleDarkMode = () => {
    setDarkMode(!darkMode);
  };

  return (
    <div className={`min-h-screen flex flex-col ${darkMode ? 'dark' : ''}`}>
      <div className="flex-grow flex flex-col bg-gray-50 dark:bg-gray-900 transition-colors duration-200">
        <Header />
        
        <button
          onClick={toggleDarkMode}
          className="absolute top-4 right-4 p-2 rounded-full bg-gray-200 dark:bg-gray-700 text-gray-800 dark:text-gray-200 
                   hover:bg-gray-300 dark:hover:bg-gray-600 transition-colors"
          aria-label="Toggle dark mode"
        >
          {darkMode ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
        </button>
        
        <main className="container mx-auto px-4 py-8 flex-grow max-w-4xl">
          <div className="bg-white dark:bg-gray-800 rounded-xl shadow-xl p-6 mb-8 transition-all duration-300">
            <h2 className="text-xl font-semibold mb-6 text-gray-800 dark:text-white">
              Check if your email is spam or ham
            </h2>
            
            <p className="text-gray-600 dark:text-gray-300 mb-6">
              Paste the content of an email below to analyze its likelihood of being spam. 
              Our machine learning model will evaluate the text and provide a prediction.
            </p>
            
            <EmailInput
              email={email}
              onChange={setEmail}
              onSubmit={checkSpam}
              onReset={resetForm}
              isLoading={isLoading}
              error={error}
            />
            
            <ResultDisplay result={result} />
          </div>
        </main>
        
        <Footer />
      </div>
    </div>
  );
}

export default App;