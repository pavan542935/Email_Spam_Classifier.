export const theme = {
  colors: {
    primary: {
      light: '#8B5CF6', // Purple 500
      DEFAULT: '#7C3AED', // Purple 600
      dark: '#6D28D9', // Purple 700
    },
    secondary: {
      light: '#93C5FD', // Blue 300
      DEFAULT: '#60A5FA', // Blue 400
      dark: '#3B82F6', // Blue 500
    },
    success: {
      light: '#A7F3D0', // Green 200
      DEFAULT: '#10B981', // Green 500
      dark: '#059669', // Green 600
    },
    danger: {
      light: '#FECACA', // Red 200
      DEFAULT: '#EF4444', // Red 500
      dark: '#DC2626', // Red 600
    },
    neutral: {
      50: '#F9FAFB',
      100: '#F3F4F6',
      200: '#E5E7EB',
      300: '#D1D5DB',
      400: '#9CA3AF',
      500: '#6B7280',
      600: '#4B5563',
      700: '#374151',
      800: '#1F2937',
      900: '#111827',
    },
    background: {
      light: '#F9FAFB',
      dark: '#111827',
    },
  },
  spacing: {
    xs: '0.25rem', // 4px
    sm: '0.5rem', // 8px
    md: '1rem', // 16px
    lg: '1.5rem', // 24px
    xl: '2rem', // 32px
    '2xl': '3rem', // 48px
  },
  borderRadius: {
    sm: '0.25rem', // 4px
    md: '0.5rem', // 8px
    lg: '1rem', // 16px
    full: '9999px',
  },
  shadows: {
    sm: '0 1px 2px 0 rgba(0, 0, 0, 0.05)',
    md: '0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06)',
    lg: '0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05)',
  },
};