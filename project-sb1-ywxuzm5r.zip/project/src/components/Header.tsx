import React from 'react';
import { Mail } from 'lucide-react';
import { APP_TITLE } from '../utils/constants';

const Header: React.FC = () => {
  return (
    <header className="bg-gradient-to-r from-purple-600 to-blue-500 text-white p-4 shadow-md">
      <div className="container mx-auto flex items-center justify-center md:justify-start">
        <Mail className="w-8 h-8 mr-3" />
        <h1 className="text-2xl font-bold">{APP_TITLE}</h1>
      </div>
    </header>
  );
};

export default Header;