import React from 'react';
import { SendHorizontal, X } from 'lucide-react';
import { PLACEHOLDER_TEXT } from '../utils/constants';

interface EmailInputProps {
  email: string;
  onChange: (email: string) => void;
  onSubmit: () => void;
  onReset: () => void;
  isLoading: boolean;
  error: string | null;
}

const EmailInput: React.FC<EmailInputProps> = ({
  email,
  onChange,
  onSubmit,
  onReset,
  isLoading,
  error,
}) => {
  return (
    <div className="w-full bg-white dark:bg-gray-800 rounded-lg shadow-md p-5 transition-all duration-300 transform hover:shadow-lg">
      <div className="mb-4">
        <label 
          htmlFor="emailContent" 
          className="block text-gray-700 dark:text-gray-200 text-sm font-medium mb-2"
        >
          Email Content
        </label>
        <textarea
          id="emailContent"
          className="w-full h-40 px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg 
                   focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent
                   bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100
                   transition-colors duration-200"
          placeholder={PLACEHOLDER_TEXT}
          value={email}
          onChange={(e) => onChange(e.target.value)}
        />
        {error && (
          <p className="mt-2 text-sm text-red-500">{error}</p>
        )}
      </div>
      <div className="flex flex-wrap gap-3">
        <button
          className="inline-flex items-center px-4 py-2 bg-gradient-to-r from-purple-600 to-blue-500 
                   text-white font-medium rounded-lg transition-all duration-300
                   hover:from-purple-700 hover:to-blue-600 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:ring-opacity-50
                   disabled:opacity-50 disabled:cursor-not-allowed"
          onClick={onSubmit}
          disabled={isLoading || !email.trim()}
        >
          {isLoading ? (
            <>
              <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
              Processing...
            </>
          ) : (
            <>
              <SendHorizontal className="w-5 h-5 mr-2" />
              Check Spam
            </>
          )}
        </button>
        <button
          className="inline-flex items-center px-4 py-2 bg-gray-200 dark:bg-gray-700 
                   text-gray-800 dark:text-gray-200 font-medium rounded-lg transition-all duration-300
                   hover:bg-gray-300 dark:hover:bg-gray-600 focus:outline-none focus:ring-2 focus:ring-gray-400 focus:ring-opacity-50"
          onClick={onReset}
          disabled={isLoading}
        >
          <X className="w-5 h-5 mr-2" />
          Clear
        </button>
      </div>
    </div>
  );
};

export default EmailInput;