import React from 'react';
import { SpamDetectionResult } from '../types';
import { RESULT_MESSAGES } from '../utils/constants';
import { AlertCircle, CheckCircle } from 'lucide-react';

interface ResultDisplayProps {
  result: SpamDetectionResult | null;
}

const ResultDisplay: React.FC<ResultDisplayProps> = ({ result }) => {
  if (!result) return null;

  const { isSpam, confidence, prediction } = result;
  
  const confidencePercent = Math.round(confidence * 100);
  
  // Determine color scheme based on prediction
  const bgColor = isSpam 
    ? 'bg-red-100 dark:bg-red-900/30' 
    : 'bg-green-100 dark:bg-green-900/30';
  
  const borderColor = isSpam 
    ? 'border-red-400 dark:border-red-700' 
    : 'border-green-400 dark:border-green-700';
  
  const textColor = isSpam 
    ? 'text-red-600 dark:text-red-400' 
    : 'text-green-600 dark:text-green-400';

  const gradientColor = isSpam
    ? 'from-red-400 to-red-600 dark:from-red-600 dark:to-red-800'
    : 'from-green-400 to-green-600 dark:from-green-600 dark:to-green-800';

  const Icon = isSpam ? AlertCircle : CheckCircle;

  return (
    <div 
      className={`w-full ${bgColor} ${borderColor} border rounded-lg p-5 mt-6 shadow-md 
                 transition-all duration-500 transform animate-fadeIn`}
    >
      <div className="flex items-center mb-3">
        <Icon className={`w-6 h-6 mr-2 ${textColor}`} />
        <h2 className={`font-bold text-lg ${textColor}`}>
          {RESULT_MESSAGES[prediction]}
        </h2>
      </div>
      
      <div className="mb-2">
        <div className="flex justify-between mb-1">
          <span className="text-sm font-medium text-gray-700 dark:text-gray-300">Confidence</span>
          <span className={`text-sm font-medium ${textColor}`}>{confidencePercent}%</span>
        </div>
        <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2.5">
          <div 
            className={`h-2.5 rounded-full bg-gradient-to-r ${gradientColor}`}
            style={{ width: `${confidencePercent}%` }}
          ></div>
        </div>
      </div>
      
      <p className="text-sm text-gray-600 dark:text-gray-400 mt-3">
        {isSpam 
          ? 'This email contains patterns commonly found in spam messages.'
          : 'This email appears to be legitimate based on its content.'}
      </p>
    </div>
  );
};

export default ResultDisplay;