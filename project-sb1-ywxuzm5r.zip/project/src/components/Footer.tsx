import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="mt-auto py-4 text-center text-sm text-gray-500 dark:text-gray-400">
      <p>© {new Date().getFullYear()} Email Spam Detector | Powered by Machine Learning</p>
    </footer>
  );
};

export default Footer;