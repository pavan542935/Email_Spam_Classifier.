import { useState } from 'react';
import { SpamDetectionResult } from '../types';
import { detectSpam } from '../services/spamDetectorService';

export const useSpamDetection = () => {
  const [email, setEmail] = useState('');
  const [result, setResult] = useState<SpamDetectionResult | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const checkSpam = async () => {
    if (!email.trim()) {
      setError('Please enter email content');
      return;
    }

    try {
      setIsLoading(true);
      setError(null);
      const detectionResult = await detectSpam(email);
      setResult(detectionResult);
    } catch (err) {
      setError('An error occurred during spam detection');
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  const resetForm = () => {
    setEmail('');
    setResult(null);
    setError(null);
  };

  return {
    email,
    setEmail,
    result,
    isLoading,
    error,
    checkSpam,
    resetForm,
  };
};