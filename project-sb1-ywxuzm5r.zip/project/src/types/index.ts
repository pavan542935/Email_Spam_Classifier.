export interface SpamDetectionResult {
  isSpam: boolean;
  confidence: number;
  prediction: 'SPAM' | 'HAM';
}